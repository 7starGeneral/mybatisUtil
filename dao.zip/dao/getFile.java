package dao.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.Uilt.CodeUilt;
import dao.Uilt.UUID;

public class getFile {
	private static String KeyNameOne = "";
	private static String JAVA_PATH_PACK = "xxx.api."; //java包路径
	private static String TABLE_NAME = "表名称";
	private static String MODULE_NAME = "对象名称";
	private static String COMMENT = "角色管理";//注释
//	private static String JAVA_PATH_URL  = "D:/Workspaces/MyEclipse Professional 2014/mldMange/src/main/java/mld/api/"; //java文件件路径
//	private static String XML_PATH_URL = "D:/Workspaces/MyEclipse Professional 2014/mldMange/src/main/resources/mapper/";  //xml文件路径
//	private static String JSP_PATH_URL = "D:/Workspaces/MyEclipse Professional 2014/mldMange/src/main/webapp/WEB-INF/jsp/"; //jsp路径
//	private static String JS_PATH_URL = "D:/Workspaces/MyEclipse Professional 2014/mldMange/src/main/webapp/dashboard/njs/"; //jsp路径
	private static String XML_PATH_URL =  "D:/s/";  //xml文件
	private static String JAVA_PATH_URL  = "D:/s/";   //java文件件路径
	private static String JSP_PATH_URL =  "D:/s/jsp/";
	private static String JS_PATH_URL  = "D:/s/njs/";
	
	
	
	public static void main(String[] args) throws SQLException {
		KeyNameOne = getKeyName();
		List<DbColumn> list = getColumn();
		//生成文件
		runFocint();
		//table表头设置
		//setDataHande(list);
		//设置页面表单初始值
//		setPageMent(list,"OrdersTable");
		
		
	}
	
	
	public static void runFocint(){
		List<DbColumn> list = getColumn();
		String beanPath = JAVA_PATH_URL+"model/"+getClaaName()+"Entity.java";
		CodeUilt.cerapath(beanPath);
		CodeUilt.writerText(setListBean(list),beanPath);//生成bean
		System.out.println("-------------"+getClaaName()+"Entity.java生成成功------------------");
		
		String xmlPath = XML_PATH_URL+getClaaName()+"Mapper.xml";
		CodeUilt.cerapath(xmlPath);
		CodeUilt.writerText(setListXml(list),xmlPath);//生成xml
		System.out.println("--------------"+getClaaName()+"Mapper.xml生成成功-----------------");
		
		String daoPath = JAVA_PATH_URL+"dao/"+getClaaName()+"DAO.java";
		CodeUilt.cerapath(daoPath);
		CodeUilt.writerText(setListDao(),daoPath);//生成Dao
		System.out.println("------------dao/"+getClaaName()+"DAO.java生成成功-------------------");
		
		String servicePath = JAVA_PATH_URL+"service/"+getClaaName()+"Service.java";
		CodeUilt.cerapath(servicePath);
		CodeUilt.writerText(setListService(),servicePath);//生成Service
		System.out.println("-------------service/"+getClaaName()+"Service.java生成成功------------------");
		
		String serviceImplPath = JAVA_PATH_URL+"service/impl/"+getClaaName()+"ServiceImpl.java";
		CodeUilt.cerapath(serviceImplPath);
		CodeUilt.writerText(setListServiceImpl(),serviceImplPath);//生成ServiceImpl
		System.out.println("-------------"+getClaaName()+"ServiceImpl.java生成成功------------------");
		
		String controllerPath = JAVA_PATH_URL+"controller/"+getClaaName()+"Controller.java";
		CodeUilt.cerapath(controllerPath);
		CodeUilt.writerText(setListController(),controllerPath);//生成controller
		System.out.println("-------------"+getClaaName()+"Controller.java生成成功------------------");
		
		String listJspPath = JSP_PATH_URL+getClaaNameNoToUpp()+"/list.jsp";
		CodeUilt.cerapath(listJspPath);
		CodeUilt.writerText(setListjsp(),listJspPath);//生成list jsp
		System.out.println("-------------list.jsp生成成功------------------");
		
		String addJspPath = JSP_PATH_URL+getClaaNameNoToUpp()+"/add"+getClaaNameNoToUpp()+".jsp";
		CodeUilt.cerapath(addJspPath);
		CodeUilt.writerText(setAddModjsp(list,"add"),addJspPath);//生成add jsp
		System.out.println("-------------add"+getClaaNameNoToUpp()+".jsp生成成功------------------");
		
		String modJspPath = JSP_PATH_URL+getClaaNameNoToUpp()+"/mod"+getClaaNameNoToUpp()+".jsp";
		CodeUilt.cerapath(modJspPath);
		CodeUilt.writerText(setAddModjsp(list,"mod"),modJspPath);//生成mod jsp
		System.out.println("-------------mod"+getClaaNameNoToUpp()+".jsp生成成功------------------");
		
		String intitJsPath = JS_PATH_URL+getClaaNameNoToUpp()+"/intit.js";
		CodeUilt.cerapath(intitJsPath);
		CodeUilt.writerText(setIntitJsPath(),intitJsPath);//生成mod jsp
		System.out.println("-------------intit.js生成成功------------------");
		
		
		System.out.println("<!-- "+COMMENT+" -->");
		System.out.println("<bean id=\""+getNoToUpp("Service")+"\" class=\"mld.api.service.impl."+getMoldeName("ServiceImpl")+"\"></bean>");
		System.out.println("");
		System.out.println("<typeAlias alias=\""+getMoldeName()+"\" type=\"mld.api.model."+getMoldeName()+"\"/>");
		
        
			 
	}
	
	/**
	 * 获取查询方法名称
	 * @return
	 */
	public static String getQeryListName(String str){
		return "get"+getClaaName()+str;
	}
	public static String getAddListName(String str){
		return "add"+getClaaName()+str;
	}
	public static String getModListName(String str){
		return "mod"+getClaaName()+str;
	}
	public static String getDelListName(String str){
		return "del"+getClaaName()+str;
	}
	/**
	 * 实体类名称
	 * @return
	 */
	public static String getMoldeName(){
		return getClaaName()+"Entity";
	}
	public static String getMoldeName(String str){
		return getClaaName()+str;
	}
	
	public static String getNoToUpp(String str){
		return getClaaNameNoToUpp()+str;
	}
	
	public static String getOneToUpperCase(String str){
		return str.substring(0, 1).toUpperCase()+str.substring(1);
	}
	
	public static String getClaaNameNoToUpp(String str){
		return getClaaNameNoToUpp()+str;
	}
	public static String getClaaNameNoToUpp(){
		return MODULE_NAME.substring(MODULE_NAME.lastIndexOf("_")+1,MODULE_NAME.length());
	}
	
	public static String getClaaName(){
		String str = MODULE_NAME.substring(MODULE_NAME.lastIndexOf("_")+1,MODULE_NAME.length());
		return getOneToUpperCase (str);
	}
	
	public static String getType(String str){
		String rs = "String";
		if("int".equals(str)){
			rs = "Integer";
		}else if("float".equals(str)){
			rs = "Float";
		}else if("decimal".equals(str)){
			rs = "Double";
		}else{
			rs = "String";
		}
		return rs;
	}
	
	
	//add js 
	public static StringBuffer setIntitJsPath(){
		StringBuffer str = new StringBuffer();
		
		str.append("  function modData("+KeyNameOne+"){   \n");			
		str.append("     var url = \""+getClaaNameNoToUpp()+"/"+getModListName("")+"?"+KeyNameOne+"=\"+ "+KeyNameOne+";  \n");			
		str.append("     window.location = url;   \n");	
		str.append("  }   \n");		
		str.append("  function addData(){   \n");			
		str.append("     var url = \""+getClaaNameNoToUpp()+"/"+getAddListName("")+"\"; \n");			
		str.append("     window.location = url;   \n");	
		str.append("  }   \n");	
		str.append("  function delData(){\n");
		str.append("     var "+KeyNameOne+" = document.getElementById(\""+KeyNameOne+"\").value;\n");		
		str.append("     var url = \""+getClaaNameNoToUpp()+"/"+getDelListName("")+"?"+KeyNameOne+"=\"+"+KeyNameOne+"; \n");
		str.append("     window.location = url;   \n");	
		str.append("  }\n");
		str.append("\n");
		str.append("  function villData() {\n");
		str.append("\n");
		str.append("\n");
		str.append("    return true;\n");
		str.append("  }\n");
	
		return str;	
	}
	
	
	//add jsp
	public static StringBuffer setAddModjsp(List<DbColumn> list,String type){
		StringBuffer str = new StringBuffer();
		str.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n");
		str.append("<%@ page language=\"java\" import=\"java.util.*\" pageEncoding=\"UTF-8\"%>\n");
		str.append("<%\n");
		str.append("  String path = request.getContextPath();\n");
		str.append("  String basePath = request.getScheme()+\"://\"+request.getServerName()+\":\"+request.getServerPort()+path+\"/\";\n");
		str.append("%>\n");
		str.append("<%@ taglib prefix=\"form\" uri=\"http://www.springframework.org/tags/form\" %>\n");
		str.append("<html>\n");
		str.append("<head>\n");
		str.append("   <base href=\"<%=basePath%>\">\n");
		if("mod".equals(type)){
			str.append("   <title>修改"+COMMENT+"</title>\n");
		}else{
			str.append("   <title>新增"+COMMENT+"</title>\n");
		}
		str.append("   <link rel=\"stylesheet\" href=\"bootstrap/css/bootstrap.css\" type=\"text/css\" />\n");
		str.append("   <link rel=\"stylesheet\" href=\"bootstrap/css/box.css\" type=\"text/css\" />\n");
		str.append("   <script src=\"bootstrap/js/jquery.min.js\"></script>\n");
		str.append("   <script src=\"bootstrap/js/bootstrap.min.js\"></script>\n");
		str.append("   <script src=\"dashboard/njs/"+getClaaNameNoToUpp()+"/intit.js\"></script>\n");
		str.append("</head>\n");
		str.append("<body>\n");
		str.append("<div class=\"container-fluid\">\n");
		str.append("<form:form  method=\"post\" modelAttribute=\"rm\" cssClass=\"form-horizontal\"> \n");
		str.append("<div class=\"panel panel-default\">\n");
		if("mod".equals(type)){
			str.append("  <div class=\"panel-heading\">修改"+COMMENT+"</div>\n");
		}else{
			str.append("  <div class=\"panel-heading\">新增"+COMMENT+"</div>\n");
		}
		str.append("   <table class=\"table table-bordered\">\n");
		if(list.size()>0){
			for(int i=0;i<list.size();i++){
				DbColumn m = list.get(i);
				if(KeyNameOne.toUpperCase().equals(m.getName().toUpperCase())){
				}else{
					if(i%2==0){
					 str.append("<tr>\n");
					}
					str.append("<td>\n");
					str.append(" <div class=\"form-group\">\n");
					str.append("  <label for=\""+m.getName()+"\" class=\"col-sm-3 control-label\">"+m.getComment()+"</label>\n");
					str.append("  <div class=\"col-sm-7\">\n");
					str.append("  <form:input path=\""+m.getName()+"\" cssClass=\"form-control\" required=\"required\" />\n");
					str.append("  </div>\n");
					str.append(" </div>\n");
					str.append("</td>\n");
					if(i%2==1){
					  str.append(" </tr>\n");
					}
					if(i+1==list.size()){
						str.append(" </tr>\n");
					}
				}
			}
		}
		str.append("<tr>\n");
		str.append("<td colspan=\"2\" align=\"right\">\n");
		if("mod".equals(type)){
			str.append("<input type=\"hidden\" name=\"parameter\" value=\"mod\">\n");
			str.append(" <form:hidden path=\""+KeyNameOne+"\"  />\n");
			str.append(" <button type=\"button\" onclick=\"delData();return false;\" class=\"btn btn-primary\"  title=\"删除\"  style=\"margin-right:50px;\"> 删 除 </button>\n");
			str.append(" <button type=\"submit\" class=\"btn btn-primary\"  title=\"修改\" style=\"margin-right:8.33%;\" > 修 改 </button>\n");
		}else{
			str.append("<input type=\"hidden\" name=\"parameter\" value=\"add\">\n");
			str.append(" <button type=\"submit\" class=\"btn btn-default\"  title=\"提交\" > 提 交 </button>\n");
		}
		
		str.append("</td>\n");
		str.append("</tr> \n");
		str.append("</table>\n");
		str.append("</div>\n");
		str.append("</form:form>\n");
		str.append("</div>\n");
		str.append("</body>\n");
		str.append("</html>\n");
		
		return str;	
	}
		
		
	//list jsp
	public static StringBuffer setListjsp(){
		StringBuffer str = new StringBuffer();
		str.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n");
		str.append("<%@ page language=\"java\" import=\"java.util.*\" pageEncoding=\"UTF-8\"%>\n");
		str.append("<%@ taglib prefix=\"c\" uri=\"http://java.sun.com/jsp/jstl/core\"%> \n");
		str.append("<%\n");
		str.append("    String path = request.getContextPath();\n");
		str.append("    String basePath = request.getScheme()+\"://\"+request.getServerName()+\":\"+request.getServerPort()+path+\"/\";\n");
		str.append("%>\n");
		str.append("<html>\n");
		str.append("<head> \n");
		str.append("   <base href=\"<%=basePath%>\">\n");
		str.append("   <title>"+COMMENT+"</title>\n");
		str.append("   <link rel=\"stylesheet\" href=\"bootstrap/css/bootstrap.css\" type=\"text/css\" />\n");
		str.append("   <link rel=\"stylesheet\" href=\"bootstrap/css/box.css\" type=\"text/css\" />\n");
		str.append("   <script src=\"bootstrap/js/jquery.min.js\"></script>\n");
		str.append("   <script src=\"bootstrap/js/bootstrap.min.js\"></script>\n");
		str.append("\n");
		str.append("   <script src=\"dashboard/njs/"+getClaaNameNoToUpp()+"/intit.js\"></script>\n");
		str.append("   <style type=\"text/css\">\n");
		str.append("    *{ font-size:14px;}\n");
		str.append("   </style>\n");
		str.append("\n");
		str.append("</head>\n");
		str.append("<body>\n");
		str.append("<div class=\"container-fluid\">\n");
		str.append("<c:if test=\"${not empty message}\">\n");
		str.append("    <div id=\"message\" class=\"alert alert-success\">\n");
		str.append("	    <button data-dismiss=\"alert\" class=\"close\">×</button>${message}</div>\n");
		str.append("	</c:if>\n");
		str.append("\n");
		str.append("		<div class=\"panel panel-default\"  style=\"margin-top:10px;\">");
		str.append("	\n");		
		str.append("			 <div>\n");
		str.append("			<div class=\"panel-heading\">\n");
	   	str.append("   <form  id=\""+getMoldeName("Form")+"\" enctype=\"application/x-www-form-urlencoded\" method=\"post\">\n");
		str.append("   <span style=\"width:50%;float:left;\">\n");
		str.append("			   <% out.println(request.getAttribute(\"pageHtml\")); %>\n");
		str.append("			   </span>\n");
		str.append("\n");					
		str.append("				  <div class=\"form-group\" style=\"width:50%; float:left;margin-top:20px; text-align:right;padding-right:40px;\">\n");
		str.append("                     <label class=\"sr-only\" for=\"exampleInputAmount\">Amount (in dollars)</label>\n");
		str.append("                     <div class=\"input-group\">\n");
		str.append("                     <div class=\"input-group-addon\" ><i class=\"glyphicon glyphicon-search\"></i></div>\n");
		str.append("			         <input type=\"text\" class=\"form-control\" id=\"exampleInputAmount\" placeholder=\"请输出查询的内容……\">\n");
		str.append("				     </div>\n");
		str.append("							    <button type=\"submit\" class=\"btn btn-primary\">查询</button>\n");
		str.append("							        <button type=\"button\" class=\"btn btn-primary\" onclick=\"addData()\"> 新 增 </button>\n");
		str.append("							  </div>\n");
	   	str.append("								</form>	 \n");
		str.append("							 </div>\n");
	    str.append("					<% out.println(request.getAttribute(\"tableHtml\")); %>\n");
	   	str.append("			      </div>\n");
        str.append("			     </div>\n");
	   	str.append("					</div>\n");
		str.append("  </body>   \n");			
		str.append(" </html>    \n");	
		str.append("     \n");
		return str;
	}
		
	
	//Controller
	public static StringBuffer setListController(){
		String xxStr = getClaaNameNoToUpp();
		String className = getMoldeName("Controller");
		String beanName =  getMoldeName("Entity"); //
		String blm =  getNoToUpp("Service"); //
		String serviceName = getMoldeName("Service");
		String countName = getMoldeName("Count");
		StringBuffer str = new StringBuffer();
		str.append("package "+JAVA_PATH_PACK+"controller;\n");
		str.append("\n");
		str.append("import mld.api.utils.Constants;\n");
		str.append("import java.util.HashMap;\n");
		str.append("import java.util.List;\n");
		str.append("import mld.api.model.PageEntity;\n");
		str.append("import javax.servlet.http.HttpServletRequest;\n");
		str.append("import mld.api.exception.IllegalRequestException;\n");
		str.append("import mld.api.utils.DataHande;\n");
		str.append("import mld.api.utils.StringUtils;\n");
		str.append("import java.util.Map;\n");
		str.append("import mld.api.model.TableDataEntity;\n");
		str.append("import org.springframework.beans.factory.annotation.Autowired;\n");
		str.append("import org.springframework.stereotype.Controller;\n");
		str.append("import org.springframework.web.bind.annotation.RequestMapping;\n");
		str.append("import mld.api.model."+beanName+";\n");
		str.append("import mld.api.service."+getMoldeName("Service")+";\n");
		str.append("import mld.api.service.CommService;\n");
		str.append("import org.springframework.web.servlet.mvc.support.RedirectAttributes;\n");
		str.append("\n");
		str.append("@Controller\n");
		str.append("@RequestMapping(\"/"+xxStr+"/\")\n");
		str.append("public class "+className+" {\n");
		str.append("\n");
		str.append("@Autowired\n");
		str.append("HttpServletRequest request;\n");
		str.append("\n");
		str.append("@Autowired\n");
		str.append("private "+getMoldeName("Service")+" "+blm+";\n");
		str.append("\n");
		str.append("@Autowired\n");
		str.append("private CommService commService;\n");
		str.append("/**\n");
		str.append("  *\n");
		str.append("  * @return\n");
		str.append("  */\n");
		str.append("@RequestMapping(value = \""+getQeryListName("List")+"\", produces = \"application/json;charset=UTF-8\")\n");
		str.append("public Object "+getQeryListName("List")+"("+beanName+" m,String limit) {\n");
		str.append("  Integer limiti = StringUtils.StringToInteger(limit, 1);\n");
		str.append("  Integer pageNum = StringUtils.StringToInteger(m.getPageNum(),Constants.PAGENUM);\n");
		str.append("  Integer beginNum = (limiti - 1) * pageNum;\n");
		str.append("  m.setBeginNum(beginNum);\n");
		str.append("  m.setPageNum(pageNum);\n");
		str.append("  \n");
		str.append("   List<TableDataEntity> ths = commService.getTableTh(\""+getClaaName()+"Table\");\n");
		str.append("   List<"+beanName+"> list = "+blm+"."+getQeryListName("List")+"(m,ths);\n");
		str.append("\n");
		str.append("   //转意map\n");
		str.append("   Map<String,String> showMap = getShowMap();\n");
		str.append("  \n");
		str.append("  PageEntity mm = new PageEntity();\n");
		str.append("  mm.setLimit(limiti);\n");
		str.append("  mm.setSumNum("+blm+"."+getQeryListName("Count")+"(m));\n");
		str.append("  mm.setPageNum(pageNum);\n");
		str.append("  mm.setFormName(\""+getMoldeName("Form")+"\");\n");
		str.append("  request.setAttribute(\"tableHtml\",DataHande.getTabel(list, ths, \""+KeyNameOne+"\", showMap));\n");
		str.append("  request.setAttribute(\"pageHtml\", DataHande.getPageHtml(mm));\n");
		str.append("  request.setAttribute(\"rm\", m);\n");
		str.append("  return \""+xxStr+"/list\";\n");
		str.append("}\n");
		str.append("\n");
		str.append("/**\n");
		str.append("  *新增\n");
		str.append("  * @param m\n");
		str.append("  * @return\n");
		str.append("  * @throws IllegalRequestException\n");
		str.append("  */\n");
		str.append("@RequestMapping(value = \""+getAddListName("")+"\",produces = \"application/json;charset=UTF-8\")\n");
		str.append("public Object "+getAddListName("")+"("+beanName+" m, String parameter,RedirectAttributes redirect)	throws IllegalRequestException {\n");
		str.append("    String url = \"redirect:/"+xxStr+"/"+getQeryListName("List")+"\";\n");
		str.append("    if (parameter==null || \"\".equals(parameter)) {\n");
		str.append("       // 初始下拉框等\n");
		str.append("       getPageInit();\n");
		str.append("      request.setAttribute(\"rm\", m);\n");
		str.append("       return \""+xxStr+"/add"+xxStr+"\";\n");
		str.append("     } else {\n");
		str.append("       //设置必填项\n");
		str.append("      // if (StringUtils.requiredFilesCheck(m.get"+getOneToUpperCase(KeyNameOne)+"())) {\n");
		str.append("       //   return \"/comm/paramIncomplete\";\n");
		str.append("      // }\n");
		str.append("       //设置默认值\n");
		str.append("       //StringUtils.reflectTest(m);\n");
		str.append("       //m.setAddTime(StringUtils.getStringDate());\n");
		str.append("       int result = "+blm+"."+getAddListName("")+"(m);\n");
		str.append("       if (result == 1) {\n");
		str.append("         redirect.addFlashAttribute(\"message\", \"创建"+COMMENT+"成功\");\n");
		str.append("       } else {\n");
		str.append("         redirect.addFlashAttribute(\"message\", \"创建"+COMMENT+"失败\");\n");
		str.append("       }\n");
		str.append("       return url;\n");
		str.append("     }\n");
		str.append("}\n");  
		str.append("\n");
		str.append("/**\n");
		str.append("  *修改\n");
		str.append("  * @param m\n");
		str.append("  * @return\n");
		str.append("  * @throws IllegalRequestException\n");
		str.append("  */\n");
		str.append("@RequestMapping(value=\""+getModListName("")+"\",produces = \"application/json;charset=UTF-8\")\n");
		str.append("public  Object "+getModListName("")+"("+beanName+" m, String parameter,RedirectAttributes redirect)  throws IllegalRequestException{\n");
		str.append("    String url = \"redirect:"+xxStr+"/"+getQeryListName("List")+"\";\n");
		str.append("       //设置必填项\n");
		str.append("       if (StringUtils.requiredFilesCheck(m.get"+getOneToUpperCase(KeyNameOne)+"())) {\n");
		str.append("          redirect.addFlashAttribute(\"message\", \"参数中缺少主键\");\n");
		str.append("          return url;\n");
		str.append("       }\n");
		str.append("      if (parameter==null || \"\".equals(parameter)) {\n");
		str.append("         "+beanName+" rm = "+blm+"."+getQeryListName("Fine")+"(m);\n");
		str.append("             if(rm==null || rm.get"+getOneToUpperCase(KeyNameOne)+"()==null || \"\".equals(rm.get"+getOneToUpperCase(KeyNameOne)+"())){\n");
		str.append("                 redirect.addFlashAttribute(\"message\", \"根据传来的主键查找不到数据\");\n");
		str.append("                 return url;\n");
		str.append("             }else{\n");
		str.append("                 // 初始下拉框等\n");
		str.append("                 getPageInit();\n");
		str.append("                 request.setAttribute(\"rm\", rm);\n");
		str.append("                 \n");
		str.append("                 return \""+xxStr+"/mod"+xxStr+"\";\n");
		str.append("            }\n");	
		str.append("      }else{ \n");
		str.append("         int result = "+blm+"."+getModListName("")+"(m);\n");
		str.append("         if (result == 1) {\n");
		str.append("            redirect.addFlashAttribute(\"message\", \"修改"+COMMENT+"成功\");\n");
		str.append("         } else {\n");
		str.append("            redirect.addFlashAttribute(\"message\", \"修改"+COMMENT+"失败\");\n");
		str.append("         }\n");
		str.append("         return url;\n");	
		str.append("  }\n");
		str.append("}\n");
		str.append("\n");
		str.append("/**\n");
		str.append("  *删除\n");
		str.append("  * @param m\n");
		str.append("  * @return\n");
		str.append("  * @throws IllegalRequestException\n");
		str.append("  */\n");
		str.append("public  Object "+getDelListName("")+"("+beanName+" m,RedirectAttributes redirect)  throws IllegalRequestException{\n");
		str.append("    String url = \"redirect:"+xxStr+"/"+getQeryListName("List")+"\";\n");
		str.append("     // 设置必填项\n");
		str.append("       if (StringUtils.requiredFilesCheck(m.get"+getOneToUpperCase(KeyNameOne)+"())) {\n");
		str.append("          redirect.addFlashAttribute(\"message\", \"参数中缺少主键\");\n");
		str.append("          return url;\n");
		str.append("       }\n");
		str.append("         int result = "+blm+"."+getDelListName("")+"(m);\n");
		str.append("         if (result == 1) {\n");
		str.append("            redirect.addFlashAttribute(\"message\", \"删除"+COMMENT+"成功\");\n");
		str.append("         } else {\n");
		str.append("            redirect.addFlashAttribute(\"message\", \"删除"+COMMENT+"失败\");\n");
		str.append("         }\n");
		str.append("         return url;\n");	
		str.append("}\n");
		
		str.append("\n");
		str.append("/**\n");
		str.append("  * 获取页面下拉框 等初始值\n");
		str.append("  */\n");
		str.append("private void getPageInit(){\n");
		str.append("  \n");
		str.append("  \n");
		str.append("}\n");
		str.append("\n");
		str.append("private Map<String,String> getShowMap(){\n");
		str.append(" return null;\n");
		str.append("}\n");
		str.append("\n");
		
		
		
		str.append("}\n");
		
		

		
		return str;
	}
	
	//ServiceImpl
	public static StringBuffer setListServiceImpl(){
		StringBuffer str = new StringBuffer();
		str.append("package "+JAVA_PATH_PACK+"service.impl;\n");
		str.append("\n");
		str.append("import java.util.List;\n");
		str.append("import mld.api.dao."+getMoldeName("DAO")+";\n");
		str.append("import mld.api.dao.TableDataDAO;\n");
		str.append("import mld.api.model.PageEntity;\n");
		str.append("import mld.api.model.TableDataEntity;\n");
		str.append("import org.springframework.beans.factory.annotation.Autowired;\n");
		str.append("import org.springframework.stereotype.Service;\n");
		str.append("import mld.api.utils.DataHande;\n");
		str.append("import mld.api.model."+getMoldeName()+";\n");
		str.append("import mld.api.service."+getMoldeName("Service")+";\n");
		str.append("\n");
		str.append("@Service\n");
		str.append("public  class "+getMoldeName("ServiceImpl")+" implements "+getMoldeName("Service")+" {\n");
		str.append("\n");
		str.append("@Autowired\n");
		str.append("private "+getMoldeName("DAO")+" "+getClaaNameNoToUpp("DAO")+";\n");
		str.append("\n");
		str.append("@Override\n");
		str.append("public List<"+getMoldeName()+"> "+getQeryListName("List")+"("+getMoldeName()+" m,List<TableDataEntity> ths){\n");
		str.append("    String colsName = DataHande.getTabelColsName(ths);\n");
		str.append("     m.setColsName(colsName);\n");
		str.append("    return "+getClaaNameNoToUpp("DAO")+"."+getQeryListName("List")+"(m);\n");
		str.append("}\n");
		str.append("\n");
		str.append("@Override\n");
		str.append("public int "+getQeryListName("Count")+"("+getMoldeName()+" m){\n");
		str.append("    PageEntity rm = "+getClaaNameNoToUpp("DAO")+"."+getQeryListName("Count")+"(m);\n");
		str.append("    if(rm!=null){\n");
		str.append("       return rm.getSumNum();\n");
		str.append("    }else{\n");
		str.append("       return 0;\n");
		str.append("    }\n");
		str.append("}\n");
		str.append("\n");
		str.append("@Override\n");
		str.append("public int "+getAddListName("")+"("+getMoldeName()+" m){\n");
		str.append("    return "+getClaaNameNoToUpp("DAO")+"."+getAddListName("")+"(m);\n");
		str.append("}\n");
		str.append("\n");
		str.append("@Override\n");
		str.append("public int "+getModListName("")+"("+getMoldeName()+" m){\n");
		str.append("    return "+getClaaNameNoToUpp("DAO")+"."+getModListName("")+"(m);\n");
		str.append("}\n");
		str.append("\n");
		str.append("@Override\n");
		str.append("public int "+getDelListName("")+"("+getMoldeName()+" m){\n");
		str.append("    return "+getClaaNameNoToUpp("DAO")+"."+getDelListName("")+"(m);\n");
		str.append("}\n");
		str.append("\n");
		str.append("@Override\n");
		str.append("public "+getMoldeName()+" "+getQeryListName("Fine")+"("+getMoldeName()+" m){\n");
		str.append("    "+getMoldeName()+" rsm = new "+getMoldeName()+"();\n");
		str.append("    List<"+getMoldeName()+"> list = "+getClaaNameNoToUpp("DAO")+"."+getQeryListName("Fine")+"(m);\n");
		str.append("    if(list.size()>0){\n");
		str.append("        return list.get(0);\n");
		str.append("    }else{\n");
		str.append("        return rsm;\n");
		str.append("    }\n");
		str.append("}\n");
		str.append("\n");
		str.append("}\n");
		
		return str;
	}
	
	//Service
	public static StringBuffer setListService(){
		StringBuffer str = new StringBuffer();
		str.append("package "+JAVA_PATH_PACK+"service;\n");
		str.append("\n");
		str.append("import java.util.List;\n");
		str.append("import mld.api.model."+getMoldeName()+";\n");
		str.append("import mld.api.model.TableDataEntity;\n");
		str.append("\n");
		str.append("/**\n");
		str.append(" * "+COMMENT+"Service\n");
		str.append(" * @author Administrator\n");
		str.append(" *\n");
		str.append(" */\n");
		str.append("public interface "+getMoldeName("Service")+"{\n");
		str.append(" /**\n");
		str.append(" *查询"+COMMENT+"列表\n");
		str.append(" */\n");
		str.append(" public List<"+getMoldeName()+"> "+getQeryListName("List")+"("+getMoldeName()+" m,List<TableDataEntity> ths); \n");
		str.append(" \n");
		str.append(" /**\n");
		str.append(" *获取"+COMMENT+"总数\n");
		str.append(" */\n");
		str.append(" public int "+getQeryListName("Count")+"("+getMoldeName()+" m);\n");
		str.append(" /**\n");
		str.append(" *新增"+COMMENT+"\n");
		str.append(" */\n");
		str.append(" public int "+getAddListName("")+"("+getMoldeName()+" m);\n");
		str.append(" /**\n");
		str.append(" *修改"+COMMENT+"\n");
		str.append(" */\n");
		str.append(" public int "+getModListName("")+"("+getMoldeName()+" m);\n");
		str.append(" /**\n");
		str.append(" *删除"+COMMENT+"\n");
		str.append(" */\n");
		str.append(" public int "+getDelListName("")+"("+getMoldeName()+" m);\n");
		str.append(" /**\n");
		str.append(" *查找"+COMMENT+"\n");
		str.append(" */\n");
		str.append(" public "+getMoldeName()+" "+getQeryListName("Fine")+"("+getMoldeName()+" m);\n");
		str.append(" \n");
		str.append("}  \n");
		
		return str;
	}
	
	//dao
	public static StringBuffer setListDao(){
		StringBuffer str = new StringBuffer();
		str.append("package "+JAVA_PATH_PACK+"dao;\n");
		str.append("\n");
		str.append("import java.util.List;\n");
		str.append("import mld.api.model."+getMoldeName()+";\n");
		str.append("import mld.api.model.PageEntity;\n");
		str.append("\n");
		str.append("/**\n");
		str.append(" * "+COMMENT+"Dao\n");
		str.append(" * @author Administrator\n");
		str.append(" *\n");
		str.append(" */\n");
		str.append("public interface "+getMoldeName("DAO")+"{\n");
		str.append(" /**\n");
		str.append(" *查询"+COMMENT+"列表\n");
		str.append(" */\n");
		str.append(" public List<"+getMoldeName()+"> "+getQeryListName("List")+"("+getMoldeName()+" m); \n");
		str.append(" \n");
		str.append(" /**\n");
		str.append(" *获取"+COMMENT+"总数\n");
		str.append(" */\n");
		str.append(" public PageEntity "+getQeryListName("Count")+"("+getMoldeName()+" m);\n");
		str.append(" /**\n");
		str.append(" *新增"+COMMENT+"\n");
		str.append(" */\n");
		str.append(" public int "+getAddListName("")+"("+getMoldeName()+" m);\n");
		str.append(" /**\n");
		str.append(" *修改"+COMMENT+"\n");
		str.append(" */\n");
		str.append(" public int "+getModListName("")+"("+getMoldeName()+" m);\n");
		str.append(" /**\n");
		str.append(" *删除"+COMMENT+"\n");
		str.append(" */\n");
		str.append(" public int "+getDelListName("")+"("+getMoldeName()+" m);\n");
		str.append(" /**\n");
		str.append(" *查找"+COMMENT+"\n");
		str.append(" */\n");
		str.append(" public List<"+getMoldeName()+"> "+getQeryListName("Fine")+"("+getMoldeName()+" m);\n");
	 	
		
		str.append("}");
		return str;
	}
	
	//xml
	public static StringBuffer setListXml(List<DbColumn> list){
		StringBuffer str = new StringBuffer();
		str.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		str.append("<!DOCTYPE mapper\n");
		str.append("PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\"\n");
		str.append("\"http://mybatis.org/dtd/mybatis-3-mapper.dtd\">\n");
		str.append("<mapper namespace=\""+JAVA_PATH_PACK+"dao."+getClaaName()+"DAO\">\n");
		str.append("<select id=\""+getQeryListName("List")+"\" resultType=\""+getMoldeName()+"\" parameterType=\""+getMoldeName()+"\">\n");
		str.append(" <if test=\"colsName != null and '' != colsName\">\n");
		str.append("  SELECT ${colsName} FROM  meilidai_test."+TABLE_NAME+" \n");
		str.append(" </if>\n");
		str.append(" <if test=\"colsName == null and '' == colsName\">\n");
		str.append(" SELECT  * FROM meilidai_test."+TABLE_NAME+" \n");
		str.append(" </if>\n");
		str.append("<if test=\"beginNum != null \"  \n>");
		str.append(" LIMIT #{beginNum},#{pageNum}  \n");
		str.append("</if>  \n");
		str.append("</select>\n");
		str.append("\n");
		str.append("<select id=\""+getQeryListName("Count")+"\" resultType=\"PageEntity\" parameterType=\""+getMoldeName()+"\">\n");
		str.append("   SELECT count("+KeyNameOne+")sumNum FROM meilidai_test."+TABLE_NAME+"\n");
		str.append("</select>\n");
		str.append("\n");
		str.append("<insert id=\""+getAddListName("")+"\" parameterType=\""+getMoldeName()+"\">\n");
		
		str.append("insert into meilidai_test."+TABLE_NAME+" (\n");
		if(list.size()>0){
			for(int i=0;i<list.size();i++){
				DbColumn m = list.get(i);
				if(KeyNameOne.toUpperCase().equals(m.getName().toUpperCase())){
		          
				}else{
					String temp = "";
					if((i+1)==list.size()){
						temp = m.getName();
					}else{
						temp = m.getName()+",";
					}
					str.append(temp+"\n");
				}
			}
		}	
		str.append("   ) values ( \n");
		if(list.size()>0){
			for(int i=0;i<list.size();i++){
				DbColumn m = list.get(i);
				if(KeyNameOne.toUpperCase().equals(m.getName().toUpperCase())){
		          
				}else{
					 
					String temp = "";
					if((i+1)==list.size()){
						temp = "#{"+m.getName()+"}";
					}else{
						temp = "#{"+m.getName()+"},";
					}
					str.append(temp+"\n");
				}
			}
		}
		str.append(")\n");
		str.append("</insert>\n");
		
		str.append("\n");
		str.append("<update id=\""+getModListName("")+"\" parameterType=\""+getMoldeName()+"\">\n");
		str.append(" update meilidai_test."+TABLE_NAME+"  SET \n");
		if(list.size()>0){
			for(int i=0;i<list.size();i++){
				DbColumn m = list.get(i);
				if(KeyNameOne.toUpperCase().equals(m.getName().toUpperCase())){
			          
				}else{
					 
					String temp = "";
					if((i+1)==list.size()){
						temp = m.getName()+" = #{"+m.getName()+"}";
					}else{
						temp = m.getName()+" = #{"+m.getName()+"},";
					}
					
					
					if(!"String".equals(getType(m.getType()))){
						str.append("<if test=\""+m.getName()+" != null \"> \n");
					}else{
						str.append("<if test=\""+m.getName()+" != null and '' != "+m.getName()+"\"> \n");
					}
					str.append("     "+temp+"\n");
					str.append(" </if>\n");
				}
			}
		}
		str.append(" where "+KeyNameOne+" = #{"+KeyNameOne+"}\n");
		str.append("</update>\n");
		str.append("\n");
		str.append("<delete id=\""+getDelListName("")+"\" parameterType=\""+getMoldeName()+"\">\n");
		str.append(" DELETE from meilidai_test."+TABLE_NAME+" where "+KeyNameOne+" = #{"+KeyNameOne+"}\n");
		str.append("</delete>\n");
		str.append("\n");
		str.append("<select id=\""+getQeryListName("Fine")+"\" resultType=\""+getMoldeName()+"\" parameterType=\""+getMoldeName()+"\">\n");
		str.append(" SELECT * FROM meilidai_test."+TABLE_NAME+" where 1=1\n");
		str.append(" <if test=\""+KeyNameOne+" != null and '' != "+KeyNameOne+"\"> \n");
		str.append("  and  "+KeyNameOne+" = #{"+KeyNameOne+"}\n");
		str.append(" </if> \n");
		str.append("</select>\n");
		str.append("</mapper>\n");
		
	return str;
	}
	
	

	//实体bean
	public static StringBuffer setListBean(List<DbColumn> list){
		StringBuffer str = new StringBuffer();
		str.append("package "+JAVA_PATH_PACK+"model;\n");
		str.append("\n");
		str.append("/**\n");
		str.append(" * "+COMMENT+"实体bean\n");
		str.append(" * @author Administrator\n");
		str.append(" *\n");
		str.append(" */\n");
		str.append("public class "+getMoldeName()+"{\n");
		if(list.size()>0){
			for(int i=0;i<list.size();i++){
				DbColumn m = list.get(i);
				str.append("private "+getType(m.getType())+" "+m.getName()+"; //"+m.getComment()+"\n");
			}
			str.append("private Integer beginNum;//开始条数\n");
			str.append("private Integer pageNum;//每页条数\n");
			str.append("private String colsName;//显示字段\n");
			for(int j=0;j<list.size();j++){
				DbColumn m = list.get(j);
				String type = getType(m.getType());
				str.append("public "+type+" get"+getOneToUpperCase(m.getName())+"(){\n");
				str.append("    return "+m.getName()+";\n");
				str.append("}\n");
				
				str.append("public void set"+getOneToUpperCase(m.getName())+"("+type+" "+m.getName()+") {\n");
				str.append("   this."+m.getName()+" = "+m.getName()+";\n");
				str.append("}\n");
				
				
			}
			str.append("public Integer getBeginNum(){\n");
			str.append("    return beginNum;\n");
			str.append("}\n");
		
			str.append("public Integer getPageNum(){\n");
			str.append("    return pageNum;\n");
			str.append("}\n");
			
			str.append("public void setBeginNum(Integer beginNum) {\n");
			str.append("   this.beginNum = beginNum;\n");
			str.append("}\n");
			
			str.append("public void setPageNum(Integer pageNum) {\n");
			str.append("   this.pageNum = pageNum;\n");
			str.append("}\n");
			
			str.append("public String getColsName() { \n");
			str.append("  return colsName;\n");
			str.append("}\n");
			
			str.append("public void setColsName(String colsName) {\n");
			str.append("   this.colsName = colsName;\n");
			str.append("}\n");
				
			
		
		}
		str.append("}");
        return str;
	}
	
	
	
	
	
	public static String getKeyName(){
		String rs = "";
		String sql = " SELECT k.column_name FROM information_schema.table_constraints t JOIN information_schema.key_column_usage k"+
		 " USING (constraint_name,table_schema,table_name)"+
		" WHERE t.constraint_type='PRIMARY KEY'"+
		  " AND t.table_name='"+TABLE_NAME+"'";
		DBHelper db1 = new DBHelper(sql);
		try {
			ResultSet ret = db1.pst.executeQuery();
			while (ret.next()) {
			rs = getStringNull(ret.getString(1));
			}
		ret.close();
		db1.close();// 关闭连接
	  } catch (SQLException e) {
		e.printStackTrace();
	   }
     return rs;
	}
	
	public static  List<DbColumn> getColumn() {
		String sql = " select COLUMN_NAME,data_type,COLUMN_COMMENT from information_schema.COLUMNS where table_name = '"+TABLE_NAME+"'";// SQL语句
		DBHelper db1 = new DBHelper(sql);
		List<DbColumn> list = new ArrayList<DbColumn>();
		try {
			ResultSet ret = db1.pst.executeQuery();
			while (ret.next()) {
				DbColumn m = new DbColumn();
				m.setName(ret.getString(1));
				m.setType(ret.getString(2));
				m.setComment(getStringNull(ret.getString(3)));
				list.add(m);
			}
			ret.close();
			db1.close();// 关闭连接
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}
	
	
	public static void setPageMent(List<DbColumn> list,String module) throws SQLException{
		if(list.size()>0){
			String sql = "DELETE from mld_zmange_pagement where module ='"+module+"'";
			DBHelper db = new DBHelper(sql.toString());
			db.pst.execute();
			for(int i=0;i<list.size();i++){
				DbColumn m = list.get(i);
				String uuid = new UUID().toString();
				StringBuffer str = new StringBuffer();
				str.append("insert into meilidai_test.mld_zmange_pagement (");
				str.append("uuid,");
				str.append("keyName,");
				str.append("value,");
				str.append("valueLength,");
				str.append("eletype,");
				str.append("module,");
				str.append("sort,");
				str.append("formatStr");
				str.append(") values (");
				str.append("'"+uuid+"',");
				str.append("'"+m.getName()+"',");
				str.append("'"+m.getComment()+"',");
				str.append("'',");
				str.append("'text',");
				str.append("'"+module+"',");
				str.append("0,");
				str.append("''");
				str.append(")");
				System.out.println(str);
				DBHelper db1 = new DBHelper(str.toString());
				db1.pst.execute();
			}
		}
	}
	
	public static void setDataHande(List<DbColumn> list) throws SQLException{
		
		if(list.size()>0){
			for(int i=0;i<list.size();i++){
				DbColumn m = list.get(i);
				if(KeyNameOne.toUpperCase().equals(m.getName().toUpperCase())){
			          
				}else{
					String uuid = new UUID().toString();
					StringBuffer str = new StringBuffer();
					str.append("INSERT into meilidai_test.mld_tabledata (uuid,keyName,value,hidden,module");
					str.append(")values(");
					str.append("'"+uuid+"',");		
					str.append("'"+m.getComment()+"',");	
					str.append("'"+m.getName()+"',");	
					str.append("'"+"true',");
					str.append("'"+getClaaName()+"Table'");
					str.append(")");	
					System.out.println(str);
					DBHelper db1 = new DBHelper(str.toString());
					db1.pst.execute();
				}
		    }
			
		}

				
	}
	
	public static String getStringNull(String str){
		if(str==null){
			return "";
		}else{
			return str;
		}
	}

}
